# Virtual Creator Studio v2 — iPhone-first

## Quick start on iPhone
1. Unzip the downloaded ZIP in the iOS Files app.
2. Open `index.html` with a browser or HTML preview app that supports JavaScript/localStorage. iOS Files preview may not persist data reliably.
3. For a reliable browser experience, upload **only `index.html`** to a static HTTPS hosting service such as GitHub Pages. Do **not** upload `server.py`, secrets, customer messages, or backup JSON.
4. Open the hosted HTTPS URL in Safari and use Share → Add to Home Screen.
5. In Settings, export JSON backups regularly. Local data does not sync across devices.

## Free hosting
Create a GitHub repository, upload `index.html`, then Settings → Pages → Deploy from a branch. GitHub Pages is publicly accessible: **do not** put credentials, personal data, or private customer records into the repository. The app has no login and its data is stored in the local browser, not GitHub.

## Features
- Dashboard, original adult fictional character profiles, caption and media prompts, post approval workflow, calendar, reply drafts, manual analytics, export/import, integration status.
- Captions and companion replies are **template-generated**, not connected to a live AI model.
- Media generation, publishing and live subscriber chat are **NOT connected**. There is no claim of automatic external publishing.

## Integration order
1. Create your verified creator accounts and read their AI/adult content rules.
2. Set up Instagram professional account and Meta developer app. Official publishing requires approved permissions, hosted public media and OAuth tokens.
3. Request Fanvue developer/API access (availability not guaranteed). Its API uses OAuth 2.0 with PKCE; do not store tokens in browser localStorage.
4. Choose a commercial-use-compatible image/video inference provider with a server-side API. Free quotas, model rights, adult-content policies and video availability vary; a free unlimited GPU is not assumed.
5. Choose a permitted LLM inference provider for AI-disclosed companion chat. Do not automate outbound fan messages without platform authorization.
6. Deploy a **private** HTTPS backend with authentication, secrets management, queue worker, moderation, logging, OAuth callback handling, and scheduled jobs.
7. Configure its URL in Integrations. The example server is for LOCAL development only, not an internet-ready service.

## Backend development (optional computer required)
`python3 server.py` starts localhost:8787. It intentionally returns HTTP 501 for all unconfigured actions. It does not post or generate content. To test browser CORS, serve the HTML at `http://localhost:8000` via `python3 -m http.server 8000` and use the backend at 8787, but the current app requires an HTTPS backend URL for remote use; for local development modify this restriction explicitly.

## Safety / privacy
- Only create clearly adult fictional personas, no real-person impersonation or unauthorized likenesses.
- Disclose AI-generated persona and automated conversations.
- Do not store provider secrets or subscriber data in this client app.
- Follow platform rules, age-gating, consumer protection, licensing, and applicable law.
- Never connect an adult-content workflow to a model/provider that forbids it.

## Architecture
`index.html` local UI → authenticated HTTPS backend (future) → approved AI generation API / official publishing API / permitted chat API. Background scheduling must run server-side, not in Safari.
