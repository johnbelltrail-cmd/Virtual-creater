"""Optional integration-ready Python server. Python 3.10+, no packages required.
Local development only. Do NOT expose to the public internet without auth, TLS,
CORS restrictions, rate limits, durable job storage and proper OAuth integration.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json, os
from urllib.parse import urlparse

class Handler(BaseHTTPRequestHandler):
    def send_json(self, code, body):
        raw=json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('Access-Control-Allow-Origin','http://localhost:8000')
        self.send_header('Access-Control-Allow-Headers','Content-Type')
        self.send_header('Access-Control-Allow-Methods','GET,POST,OPTIONS')
        self.end_headers(); self.wfile.write(raw)
    def do_OPTIONS(self): self.send_json(200, {'ok':True})
    def do_GET(self):
        if urlparse(self.path).path=='/api/health': return self.send_json(200,{'ok':True,'mode':'integration placeholders only','image':False,'video':False,'publish':False,'chat':False})
        return self.send_json(404,{'error':'Unknown route'})
    def do_POST(self):
        if int(self.headers.get('Content-Length','0'))>65536:return self.send_json(413,{'error':'Request too large'})
        try: body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
        except Exception:return self.send_json(400,{'error':'Invalid JSON'})
        path=urlparse(self.path).path
        if path=='/api/publish':
            if body.get('status') not in ('Approved','Scheduled'):return self.send_json(403,{'error':'Approval required'})
            return self.send_json(501,{'message':'Not published: configure official OAuth integration, media hosting, compliance checks and scheduling worker.'})
        if path=='/api/generate':return self.send_json(501,{'message':'Generation not configured: connect a commercially licensed image/video model provider.'})
        if path=='/api/chat':return self.send_json(501,{'message':'Messaging not configured: connect a permitted LLM and approved platform messaging API.'})
        return self.send_json(404,{'error':'Unknown route'})

if __name__=='__main__':
    port=int(os.environ.get('PORT','8787'))
    print(f'Integration placeholder server: http://localhost:{port}')
    ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
